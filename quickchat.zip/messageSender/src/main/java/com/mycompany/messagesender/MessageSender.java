/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messagesender;

/**
 *
 * @author User
 */
import java.util.Random;
import java.util.Scanner;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

class Message
{
    private String messageId;
    private int nomessageSent;
    private String recipient;
    private String message;
    private String messageHash;
    private static int messageCounter = 0;
    
    public Message(String recipient, String message, int nomessageSent)
    {
        this.messageId = generateMessageId();
        this.nomessageSent = nomessageSent;
        this.recipient = recipient;
        this.messageHash = createMessageHash();
    }
    private String generateMessageId()
    {
        Random random = new Random();
        long id = 1000000000L + (long)(random.nextDouble() * 90000000000L);
        
        return String.valueOf(id);
    }
    boolean checkMessageID()
    {
       return messageId != null && messageId.length() <= 10;
    }
    String checkRecipientCell()
    {
      if(recipient != null && recipient.length() <= 10 && recipient.startsWith("+") || recipient.matches("\\d+"))
      {
          return "Valid";
      }
      else
      {
          return "Invalid: Recipient number must be equal to 10 characters and contain international code";
      }
    }
    String createMessageHash()
    {
        String[] words = message.trim().split("\\s+");
        String firstWord = words.length > 0 ? words [0] : " ";
        String lastWord = words.length > 0 ? words[words.length - 1] : " ";
        
        String firstTwoDigits = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
        String hash = firstTwoDigits + ":" + nomessageSent + ":" + firstWord + ":" +lastWord;
        
        return hash.toUpperCase();
    }
    String sentMessage()
    {
       System.out.println("\n--- Message Options ---");
       System.out.println("1. Send message");
       System.out.println("2. Disregard Message");
       System.out.println("3. Store Message to send later");
       
       int choice = Scanner.nextInt();
       Scanner.nextLine();
       
       switch(choice)
       {
           case 1:
               return "Message successfully sent";
           case 2:
               System.out.println("Press 0 to delete the message:");
               int confirm = Scanner.nextInt();
               if(confirm == 0)
               {
                  return "Message deleted";
               }
               return "Message kept";
           case 3:
               storeMessage();
               return "Message successfully stored";
           default:
               return "Invalid option";
       }
    }
    void storeMessage()
    {
       try
       {
           JSONObject jsonMessage = new JSONObject();
           jsonMessage.put("messageID", messageId);
           jsonMessage.put("nomessageSent", nomessageSent);
           jsonMessage.put("recipient", recipient);
           jsonMessage.put("message", message);
           jsonMessage.put("messageHash", messageHash);
           jsonMessage.put("timestamp", System.currentTimeMillis());
           
           File file = new File("messages.json");
           JSONObject allMessages;
           
           if(file.exists())
           {
               allMessages = new JSONObject();
               allMessages.put("messages", new org.json.JSONArray());
           }
           else
           {
               allMessages = new JSONObject();
               allMessages.put("messages", new org.json.JSONArray());
           }
           org.json.JSONArray messageArray = allMessages.getJSONArray("messages");
           messageArray.put(jsonMessage);
           allMessages.put("messages", messageArray);
           
           try (FileWriter fileWriter = new FileWriter("message.json"))
           {
               fileWriter.write(allMessages.toString(4));
               System.out.println("Message stored in messages.json");
           }
       }
       catch (IOException e)
       {
           System.out.println("Error storing message: " + e.getMessage());
       }
    }
    String printMessage(java.util.ArrayList<Message>messages)
    {
      if(messages.isEmpty())
      {
          return "No messages sent yet.";
      }
      
      StringBuilder output = new StringBuilder();
      output.append("============== All Messages ============");
      for (int i = 0; i < message.size(); i++)
      {
          Message m = messages.get(i);
          output.append("-------Message ").append(i+1).append(" --------");
          output.append("Message ID: ").append(m.messageId);
          output.append("Message Hash: ").append(m.messageHash);
          output.append("Recipient: ").append(m.recipient);
          output.append("Message: ").append(m.message);
          output.append("Number sent: ").append(m.nomessageSent);
          output.append("--------------------------");
      }
      return output.toString();
    }
    int returnTotalMessages(java.util.ArrayList<Message> messages)
    {
        return message.size();
    }
    void displayMessage()
    {
        System.out.println("-----Message details -----");
        System.out.println("Message ID: "+messageId);
        System.out.println("Message Hash: "+messageHash);
        System.out.println("Recipient: "+recipient);
        System.out.println("Message: "+message);
        System.out.println("Number sent: "+nomessageSent);
    }
    public String getMessageId()
    {
        return messageId;
    }
    public String getMessageHash()
    {
        return messageHash;
    }
    public String getRecipient()
    {
        return recipient;
    }
    public String getMessage()
    {
        return message;
    }
    public int getNomessageSent()
    {
        return nomessageSent;
    }
}

import java.util.ArrayList;
import java.util.Scanner;

public class MessageSender {
    private static ArrayList<Message> messages = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int totalMessagesToSend;
    private static int messagesSent = 0;
    private static boolean loggedIn = false;

    public static void main(String[] args) {
        if(login())
        {
            loggedIn = true;
            System.out.println("Login Successful!");
            
            System.out.println("============================");
            System.out.println("Welcome to the Message Sender");
            
            System.out.print("How many messages would you like tp send?");
            totalMessagesToSend = scanner.nextInt();
            
            boolean quit = false;
            while(!quit && messagesSent < totalMessagesToSend)
            {
                displayMenu();
                int choice = scanner.nextInt();
                scanner.nextLine();
                
                switch(choice)
                {
                    case 1: 
                        sendMessage();
                        break;
                    case 2:
                        System.out.println("This feature is still in development");
                        break;
                    case 3:
                        System.out.println("Thank you for using this Message Sender");
                        quit = true;
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
                if (messagesSent >= totalMessagesToSend && !quit)
                {
                   System.out.println("===================================="); 
                   System.out.println("You have reachedyour message limit!");
                   System.out.println("=====================================");
                   displayAllMessages();
                   System.out.println("Total messages sent: "+Message.returnTotalMessages(messages));
                }
            }
        }
        else
        {
            System.out.println("Login Failed.");
        }
        scanner.close();
    }
    private static boolean login()
    {
        System.out.println("====================");
        System.out.println("Messager Login");
        System.out.println("====================");
        
        System.out.println("Enter username: ");
        String username = scanner.nextLine();
        
        System.out.println("Enter password: ");
        String password = scanner.nextLine();
        
        if(username.equals("user") && password.equals("pass"))
        {
            return true;
        }
        else
        {
        System.out.println("Inavlid username or password!");
        return false;
        }
    }
    private static void displayMenu()
    {
        System.out.println("-------Main Menu------");
        System.out.println("Option 1. Send Messages");
        System.out.println("Option 2. Show recently sent messages");
        System.out.println("Option 3. Leave");
        System.out.println("Choose ONE option");
    }
    private static void sendMessage()
    {
        System.out.println("-----Compose a new message------");
        System.out.println("Amount of messages left: "+(totalMessagesToSend - messagesSent));
        
        String recipient = scanner.nextLine();
        
        if(recipient.length() > 10)
        {
            System.out.println("Invalid!! Recipient number must have 10 characters");
        }
        
        System.out.println("Enter your message (max 250 characters): ");
        String messageText = scanner.nextLine();
        
        if(messageText.length() > 250)
        {
            System.out.println("Your message needs to consist of characters less than 250");
        }
        
        System.out.println("Message Sent!");
        
        messagesSent++;
        
        Message newMessage = new Message(recipient, messageText, messagesSent);
        
        String cellValidation = newMessage.checkRecipientCell();
        if(!cellValidation.equals("Valid"))
        {
            System.out.println(cellValidation);
        }
        
        String result = newMessage.sentMessage();
        System.out.println(result);
        
        messages.add(newMessage);
        
        newMessage.displayMessage();
        System.out.println("Message Hash: "+newMessage.getMessageHash());
    }
    private static void displayAllMessages()
    {
        System.out.println(Message.printMessages(messages));
        System.out.println("Total number of messages sent: "+Message.returnTotalMessages(messages));
    }
}
